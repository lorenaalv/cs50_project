# cs50_project
# Introductory Video to Our Project: https://youtu.be/9B9clOt4jaw
# To be able to run our project, log into https://cs50.dev/
# In the terminal, execute the command " cd ~ " to change to your main directory outside of CS50 management
# In the terminal, now execute the git command " git clone https://github.com/lorenaalv/cs50_project.git "
# In the terminal, navigate to the cs50_project directory by running the command " cd cs50_project "
# To run the project, in the terminal, run the command " flask run " and wait for a link to be generated
# Click on the link in the terminal to open the live link to our website
# Begin using the website by registering for an account through the register page found in the navigation bar
# Log into your account by inputting all necessary information into the log in form
# Read through the home page to learn about our website and the purpose it serves
# Click over to log purchases page through the navigation bar and begin to log the purchases you make on the road
# You will be redirected to the view purchases page where you can see the table of data you have generated
# Click over to the map page through the navigation bar or the hyperlink found at the bottom of the view purchases page
# Use the mouse pad to zoom in and out of the Google Map
# Test hovering over the marker of your purchase to view the title of the purchase you made
# Keep roadtripping and logging you purchases!
